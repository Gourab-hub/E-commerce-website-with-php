<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
  #submit{
        display: block;
        margin: auto;
        padding-left: 40px;
        padding-right: 40px;
    }
    .about{
          left: 0px;
          margin-top: 20px;
          height: 100px;
          width: 200px;
      }
      textarea .wt-resize{
          resize: none;
          overflow: hidden;
      }
  </style>
</head>
<body>
<!-- Contact Page  -->
    <div class="container">
        <div class="center">
            <div class="content">
                <h1>Live Support</h1>
                <h3>24 Hours | 7 Days In a Week | 365 Days in a Year | Free Technical Support</h3>
                <p>Technical support (often shortened to tech support) refers to services that entities provide to users of technology products or services. In general, technical support provide help regarding specific problems with a product or service, rather than providing training, provision or customization of product, or other support services. Most companies offer technical support for the services or products they sell, either included in the cost or for an additional fee. Technical support may be delivered over by phone, e-mail, live support software on a website, or other tool where users can log an incident. Larger organizations frequently have internal technical support available to their staff for computer-related problems. </p>
            </div>
            <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8" style="margin:20px;">
                <h1 style="text-align: center;">Contact Us</h1>
                <form class="form form-horizontal" style="margin-top: 20px; margin-bottom: 50px;" method="post">
                    <!-- Name field  -->
                    <div class="form-group form-group-md">
                        <label class="col-lg-3 control-label">Name: </label>
                        <div class="col-lg-7">
                            <input class="form-control" type="text" name="Name" placeholder="Enter your name">
                        </div>
                    </div>
                    <!-- Email field  -->
                    <div class="form-group form-group-md">
                        <label class="col-lg-3 control-label">E-mail: </label>
                        <div class="col-lg-7">
                            <input class="form-control" type="email" name="email" placeholder="Enter your email">
                        </div>
                    </div>
                    <!-- Complain Field  -->
                    <div class="form-group form-group-md">
                        <label class="col-lg-3 control-label">Issue: </label>
                        <div class="col-lg-7">
                            <textarea class="wt-resize" name="iss" id="iss" cols="56" rows="3" placeholder="How can I help you?" ></textarea>
                            <!-- <input class="form-control" type="text" name="iss" placeholder="How can I help you?" id="iss" > -->
                        </div>
                    </div>
                    <!-- Submit button  -->
                    <input class="btn btn-success" id="submit"type="submit" value="Submit" name="submit">
                </form>
                </div>
                <div class="col-lg-3">
                <h1>Company Information</h1>
                <img class="about" src="about.jpeg" alt="cat">
                <p> <strong>Address: </strong> Jung khayela tabela, Chindi Market ,Sansanati Gali</P>
                <p><strong>Fax: </strong>420-840-024</p>
                <p><Strong>Email: </Strong>Kaisanho@gmail.com</p>
                <p><strong>Contact No:</strong>91-8637858431</p>
                </div>
            </div>
        </div>
        </div>
    </div>
     <!-- footer  -->
     <?php 
      include('footer.php');
      ?>
</body>
</html>