<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap3/css/bootstrap.min.css">
    <link rel="stylesheet" href="nav.css">
    <title>Index Page</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        body{
            color:black;
        }
    #banner-image{
        padding-top: 170px;
        padding-bottom: 150px;
        text-align: center;
        color: #000000;
        background: url(bg2.jpg) no-repeat center center;
        background-size: cover;

    }
    .banner-content{
        position: relative;
        padding-top: 6%;
        padding-bottom: 6%;
        margin: auto;
        background-color: rgb(7, 7, 7);
        max-width: 660px;
        opacity: 0.9;
    }
    .banner-content #shop{
        opacity: 1.5;
    }
    .content{
        color: white;
        font-weight: bold;
    }
    .active{
        background-color: rgb(239, 240, 241);
        color: rgb(10, 10, 10);
    }
    h1{
        color: white;
    }
    </style>
</head>

<body>
    <?php
      if(isset($_POST["shop"]))
      {
        header('location:login.php');
      }
    ?>
    <!-- navbar  -->
    <div class="header">
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Lifestyle Store</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" class="btn active"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                    <!-- <li><a href="product.php" class="btn"><span class="glyphicon glyphicon-search"></span> Product</a></li>
                    <li><a href="cart.html" class="btn"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li> -->
                    <li><a href="register.php" class="btn"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>
                    <li><a href="login.php" class="btn"><span class="glyphicon glyphicon-log-in"></span> Log in</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
    <!-- container  -->
    <div id="banner-image">
        <div class="container">
            <div class="banner-content">
                <h1 class='content'>Shopping is Going On</h1><br>
                <h3 class='content'>Hurry Up</h3><br>
                <p class='content'>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Veniam, minima.</p>
                <form method="post">
                  <input class="btn btn-danger" id="shop"type="submit" value="Shop Now" name="shop">
                </form>
            </div>
        </div>
    </div>
 <!-- footer  -->
      <?php 
      include('footer.php');
      ?>
</body> 
</html>