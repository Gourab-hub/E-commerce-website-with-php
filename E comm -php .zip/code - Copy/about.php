<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
      .content{
          /* border: 2px solid green; */
          padding:20px;
          margin:10px;
      }
      .about{
          left: 0px;
          top: 0px;
          height: 100px;
          width: 100px;
      }
  </style>
</head>
<body>

 <!-- navbar  -->
 <div class="header">
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Lifestyle Store</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" class="btn active"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                    <li><a href="product.php" class="btn"><span class="glyphicon glyphicon-search"></span> Product</a></li>
                    <li><a href="cart.html" class="btn"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                    <li><a href="register.php" class="btn"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>
                    <li><a href="login.php" class="btn"><span class="glyphicon glyphicon-log-in"></span> Log in</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<!-- About page  -->
    <div class="container-fluid" >
    <div class="row" style="margin-top: 50px;">
        <div class="content col-md-4" >
            <h1>Information</h1>
            <img class="about" src="about.jpeg" alt="aboutus">
            <p>This Company was founded in the year of 2020, at a very crucial time of world economy. <strong>'Apna Dukan'</strong> is an Indian e-commerce company based in Bangalore, Karnataka, India. It was founded by Sachin Bansal and Binny Bansal in 2007. The company initially focused on book sales, before expanding into other product categories such as consumer electronics, fashion, home essentials & groceries, and lifestyle products.</P>

            <p>The service competes primarily with Amazon's Indian subsidiary, and the domestic rival Snapdeal.[5][6] As of March 2017, Flipkart held a 39.5% market share of India's e-commerce industry.[7] Flipkart is significantly dominant in the sale of apparel (a position that was bolstered by its acquisition of Myntra), and was described as being "neck and neck" with Amazon in the sale of electronics and mobile phones.[8] Flipkart also owns PhonePe, a mobile payments service based on the Unified Payments Interface (UPI).</p>
        </div>
        <div class="content col-md-3">
            <h1>Our History</h1>
            <p>
            <strong>'Apna Dukan'</strong>was founded in October 2007 by Sachin Bansal and Binny Bansal, who were both alumni of the Indian Institute of Technology Delhi and formerly worked for Amazon.[10][11][12] The company initially focused on online book sales with country-wide shipping. Following its launch, Flipkart slowly grew in prominence; by 2008, it was receiving 100 orders per day. In 2010, Flipkart acquired the Bangalore-based social book discovery service weRead from Lulu.com.</p>

            <p>In late 2011, Flipkart made several acquisitions relating to digital distribution, including Mime360.com and the digital content library of Bollywood portal Chakpak.</p>

            <p>In February 2012, the company unveiled its DRM-free online music store Flyte. However, the service was unsuccessful due to competition from free streaming sites, and shut down in June 2013.</p>
            </div>
            <div class="content col-md-4">
            <h1>Contact us</h1>
                    <p> Contact:+91-123-000000</p>
            </div>
            </div>
    </div>
     <!-- footer  -->
     <?php 
      include('footer.php');
      ?>
</body>
</html>