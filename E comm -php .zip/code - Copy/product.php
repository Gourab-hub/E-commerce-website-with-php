<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
    body
    {
            background: url(bg1.jpeg);
    }
    .product{
        margin-top: 70px;
    }
    .caption{
        text-align: center;
    }
    .price{
        float:left;
    }
    .active{
        background-color: rgb(239, 240, 241);
        color: rgb(10, 10, 10);
    }
    </style>
</head>

<body>
    <!-- PHP Codes  -->
    <?php 

        $item="";
        if(isset($_POST["item1"]))
        {
            $item = "Go to cart";
        }
    ?>


    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Lifestyle Store</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" class="btn"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                    <li><a href="product.php" class="btn active"><span class="glyphicon glyphicon-search"></span> Product</a></li>
                    <li><a href="settings.php" class="btn"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
                    <li><a href="cart.php" class="btn"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                    <li><a href="index.php" class="btn"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
                </ul>
            </div>
        </div>
    </nav>
<div class="container-fluid product">

    <div class="row">
        <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
            <div class="thumbnail">
                <img src="1.jpg" alt="cat">
                <div class="caption">
                    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius? flgkpokdmvbjkijxcvkmvlkvcxjk o</p>
                    <p class="price">400/-</p><br>
                    <form action="cart.php" method="post">
                        <input type="submit" class="button btn-lg btn-danger" value="Grab Now" name="item1">
                        <?php echo "$item"; ?>
                        <!-- <button class="button btn-lg btn-danger" name="1" >Grab Now</button> -->
                    </form>
                </div>
            </div>
        </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="2.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="3.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="4.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="5.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="6.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="12.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius  </p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="11.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?  </p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="9.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="10.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="13.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 col-xl-2 col-sm-6 ">
                <div class="thumbnail">
                    <img src="14.jpg" alt="cat">
                    <div class="caption">
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Totam, eius?</p>
                        <p class="price">400/-</p><br>
                        <button class="button btn-lg btn-danger">Grab Now</button>
                    </div>
                </div>
            </div>
    </div>
    </div>
    <?php 
      include('footer.php');
      ?>
</body>
</html>