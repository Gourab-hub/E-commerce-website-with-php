<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log in</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
    .form-group::placeholder{
        text-align: center;
    }
    #login{
        display: block;
        margin: auto;
        padding-left: 40px;
        padding-right: 40px;
    }
    .container p{
      text-align: center;
      
    }
    p{
      text-align:center;
    }
    .error{
      color:red;
    }
    .form{
      display:block;
      margin:auto;
    }
    .field-icon {
      float: right;
      margin-left: -25px;
      margin-top: -25px;
      position: relative;
    z-index: 2;
    }
    .active{
        background-color: rgb(239, 240, 241);
        color: rgb(10, 10, 10);
    }
  </style>
</head>
<body>
    <!-- php  -->
    <?php
  $emailErr = $passErr = "";
  $log="";
  if(isset($_POST["login"]))
  {
    //   Email verification
    if(empty($_POST["email"]))
    {
        $emailErr = "E-mail is Mandatory";
    }
    else
    {
        if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))
        {
            $emailErr = "Invalid e-mail format, enter in '@exaple.com' format";
        }
        else
        {
            $email = $_POST["email"];
        }
    }
    $password=$_POST["pass"];

    // echo "$email<br>";
    // echo "$password<br>";
    // connect database
    $host='localhost';
    $dbuser='root';
    $passw='';
    $dbname='project';
    $conn=new mysqli($host, $dbuser, $passw,$dbname);
    // Check connection
    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    else
    {
      $sql="SELECT Password FROM project.signup WHERE Email='$email' ";
      $retval=mysqli_query($conn, $sql);

      if(mysqli_num_rows($retval) > 0)
      {
        while($row = mysqli_fetch_assoc($retval))
        {
          if($row['Password'] == $password)
          {
              // $log = "Sucess";
              session_start();
              $_SESSION["login"] = $email;
              header('location:product.php');
          }
          else
          {
            $log = "Failed";
          }
        }
      }
      else
      {
         $emailErr = "You have no account please sign in";
      }
    }
  }
  ?>
      <!-- navbar  -->
    <div class="header">
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Lifestyle Store</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" ><span class="glyphicon glyphicon-home"></span> Home</a></li>
                    <!-- <li><a href="product.php" class="btn"><span class="glyphicon glyphicon-search"></span> Product</a></li>
                    <li><a href="cart.html" class="btn"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li> -->
                    <li><a href="register.php" class="btn"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>
                    <li><a href="login.php" class="btn active"><span class="glyphicon glyphicon-log-in"></span> Log in</a></li>
                </ul>
            </div>
        </div>
    </nav>
  </div>
    <div class="container">
      <form class="form form-horizontal" style="margin-top: 100px;" method="post">
        <p><span class="error">*Don't forget to fill up required field</span></p>
           <p><?php echo $log;?></p> 
          <!-- email field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">E-mail: </label>
            <div class="col-sm-5">
              <input class="form-control" type="email" name="email" placeholder="Enter your email">
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $emailErr;?></span>
            </div>
          </div>
          <!-- Password Field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">Password: </label>
            <div class="col-sm-5">
              <input class="form-control" type="password" name="pass" placeholder="Enter password" id="pass" >
              <!-- checkbox to show and hide data  -->
              <input type="checkbox" onclick="myFunction('pass')">Show Password
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $passErr;?></span>
            </div>
          </div>
          <!-- Log in button  -->
          <input class="btn btn-success" id="login"type="submit" value="Log in" name="login">
          <p>Are you a new user? Click on  <a href="register.php"> Sign up</a></p>
        </form>
      </div>
        <!-- Show and Hide script  -->
      <script>
      function myFunction(id) 
      {
        var x = document.getElementById(id);
        if (x.type === "password")
        {
          x.type = "text";
        }
        else
        {
          x.type = "password";
        }
      }
      </script>

</body>
</html>