<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    .form-group::placeholder{
        text-align: center;
    }
    #Signup{
        display: block;
        margin: auto;
        padding-left: 40px;
        padding-right: 40px;
    }
    .container p{
      text-align: center;
      
    }
    p{
      text-align:center;
    }
    .error{
      color:red;
    }
    .form{
      display:block;
      margin:auto;
    }
    .field-icon {
      float: right;
      margin-left: -25px;
      margin-top: -25px;
      position: relative;
    z-index: 2;
    }
    .active{
        background-color: rgb(239, 240, 241);
        color: rgb(10, 10, 10);
    }
  </style>
<body>

    <?php
    // $name = $email= $pass = $re_pass = "";
    $nameErr = $emailErr = $passErr = $re_passErr = "";
    if(isset($_POST["Signup"]))
    {
      // Name Validation
      if($_POST['name']=="")
      {
        $nameErr = "Name is Mandatory";
      }
      else
      {
        if(!preg_match("/^[a-zA-Z ]*$/",$_POST['name']))
      // else if(!ctype_alpha($_POST["name"]))
        {
           $nameErr="Invalid format";
        }
        else
        {
          $name=$_POST["name"];
        }

      }

      // Email Validation
      if(empty($_POST["email"]))
      {
        $emailErr = "E-mail is Mandatory";
      }
      else
      {
        if(!filter_var($_POST["email"], FILTER_VALIDATE_EMAIL))
        {
          $emailErr = "Invalid e-mail format, enter in '@exaple.com' format";
        }
        else
        {
          $email = $_POST["email"];
        }
      }

      // Password Varification
      if(empty($_POST["pass"]))
      {
        $passErr = "Please enter your password";
      }
      $uppercase = preg_match('@[A-Z]@', $_POST["pass"]);
      $lowercase = preg_match('@[a-z]@', $_POST["pass"]);
      $number    = preg_match('@[0-9]@', $_POST["pass"]);
      $specialChars = preg_match('@[^\w]@', $_POST["pass"]);

      if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($_POST["pass"]) < 8) 
      {
        $passErr = "Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.";
      }
      else
      {
        $passErr = 'Strong password.';
        // Re valid password 
        if($_POST["pass"] != $_POST["re_pass"])
        {
          $re_passErr = "Confirm password does not match with the password";
        }
        else
        {
          $password = $_POST["pass"];
          // $re_pass = md5($_POST["re_pass"]);
        }
      }

      $host='localhost';
      $dbuser='root';
      $pass='';
      $dbname='project';
      $conn=new mysqli($host, $dbuser, $pass,$dbname);
    // Check connection
      if ($conn->connect_error) 
      {
          die("Connection failed: " . $conn->connect_error);
      }
      else
      {
        if(($name !="") && ($email !="") && ($password !=""))
        {
          $user_varf = "SELECT Id FROM signup WHERE Email = '$email'";
          if(mysqli_num_rows($user_varf) > 0)
          {
            $emailErr = "Already registered";
          }
          else
          {
            $sql_data = "INSERT INTO signup (Name, Email,Password)VALUES('$name','$email','$password')";
            if ($conn->query($sql_data) == TRUE)
            {
              header("location: login.php");
            }
            else
            {
              echo "Error: " . $sql_data . "<br>" . $conn->error;
            }
          }
        }

      }
    }
    ?>
    <!-- navbar  -->
    <div class="header">
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Lifestyle Store</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <!-- <li><a href="#"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                    <li><a href="#"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
                    <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Log in</a></li> -->
                    <li><a href="index.php" class="btn "><span class="glyphicon glyphicon-home"></span> Home</a></li>
                    <li><a href="product.php" class="btn"><span class="glyphicon glyphicon-search"></span> Product</a></li>
                    <li><a href="cart.html" class="btn"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                    <li><a href="register.php" class="btn active"><span class="glyphicon glyphicon-user"></span> Sign up</a></li>
                    <li><a href="login.php" class="btn"><span class="glyphicon glyphicon-log-in"></span> Log in</a></li>
                </ul>
            </div>
        </div>
    </nav>
</div>
<!-- Sign up form  -->
<div class="container" style="margin-top: 100px;">
  <div class="row">
    <div class="col-lg-5" style="margin:20px;">
    <img src="s3.jpg" alt="bg" style="left:0px;width: 400px;">
    </div>
    <div class="col-lg-6">
      <form class="form form-horizontal" style="margin-top: 100px; margin-bottom:20px;" method="post">
        <p><span class="error">*Don't forget to fill up required field</span></p>
        <!-- Name field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">Name: </label>
            <div class="col-sm-5">
              <input class="form-control" type="text"name="name" placeholder="Enter your name">
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $nameErr;?></span>
            </div>
          </div>
          <!-- email field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">E-mail: </label>
            <div class="col-sm-5">
              <input class="form-control" type="email" name="email" placeholder="Enter your email">
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $emailErr;?></span>
            </div>
          </div>
          <!-- Password Field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">Password: </label>
            <div class="col-sm-5">
              <input class="form-control" type="password" name="pass" placeholder="Enter password" id="pass" >
              <!-- checkbox to show and hide data  -->
              <input type="checkbox" onclick="myFunction('pass')">Show Password
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $passErr;?></span>
            </div>
          </div>
          <!-- Confirm Password Field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">Confirm Password: </label>
            <div class="col-sm-5">
              <input class="form-control" type="password" name="re_pass"  placeholder="Please re-enter password" id="re_pass">
              <!-- checkbox to show and hide data  -->
              <input type="checkbox" onclick="myFunction('re_pass')">Show Password
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $re_passErr;?></span>
            </div>
          </div>
          <!-- Sign up button  -->
          <input class="btn btn-success" id="Signup"type="submit" value="Sign up" name="Signup">
          <p>Alredy have an account  <a href="login.php"> Log in</a></p>
        </form>
      </div>
        <!-- Show and Hide script  -->
      <script>
      function myFunction(id) 
      {
        var x = document.getElementById(id);
        if (x.type === "password")
        {
          x.type = "text";
        }
        else
        {
          x.type = "password";
        }
      }
      </script>
  </div>
</div>
 <!-- footer  -->
 <?php 
      include('footer.php');
      ?>
</body>
</html>