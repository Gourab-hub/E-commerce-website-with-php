<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
    .active{
        background-color: rgb(239, 240, 241);
        color: rgb(10, 10, 10);
    }
    .form-group::placeholder{
        text-align: center;
    }
    #update{
        display: block;
        margin: auto;
        padding-left: 40px;
        padding-right: 40px;
    }
    .container p{
      text-align: center;
      
    }
    p{
      text-align:center;
    }
    .error{
      color:red;
    }
    .form{
      display:block;
      margin:auto;
      padding:20px;
    }
    </style>
</head>

<body>
<!-- php codes  -->
<?php 
    $passErr = $New_passErr =$reNew_passErr="";
   

    if(isset($_POST['update']))
    {
        if(empty($_POST['oldpass']))
        {
            $passErr="Password can't be blank";
        }
        else
        {
            $oldpass=$_POST['oldpass'];
        }
         // Password Varification
      if(empty($_POST["New_pass"]))
      {
        $emailErr = "Please enter your password";
      }
      $uppercase = preg_match('@[A-Z]@', $_POST["New_pass"]);
      $lowercase = preg_match('@[a-z]@', $_POST["New_pass"]);
      $number    = preg_match('@[0-9]@', $_POST["New_pass"]);
      $specialChars = preg_match('@[^\w]@', $_POST["New_pass"]);

      if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($_POST["New_pass"]) < 8) 
      {
        $New_passErr = "Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.";
      }
      else
      {
        $New_passErr = 'Strong password.';
        // Re valid password 
        if($_POST["New_pass"] != $_POST["reNew_pass"])
        {
          $re_passErr = "Confirm password does not match with the password";
        }
        else
        {

          $Newpass = $_POST["New_pass"];
          // $re_pass = md5($_POST["re_pass"]);
        }
      }
      $host='localhost';
      $dbuser='root';
      $pass='';
      $dbname='project';
      $conn=new mysqli($host, $dbuser, $pass,$dbname);
    // Check connection
      if ($conn->connect_error) 
      {
          die("Connection failed: " . $conn->connect_error);
      }
      session_start();
      $email=$_SESSION["login"];
      if(($oldpass!="") && ($Newpass!=""))
      {
            $sql_pass="SELECT Password FROM signup WHERE Email='$email'";
            $retval=mysqli_query($conn, $sql_pass);
            if(mysqli_num_rows($retval) > 0)
            {
                while($row = mysqli_fetch_assoc($retval))
                {
                    if($row['Password'] == $oldpass)
                    {
                        $up_sql="UPDATE signup SET Password = '$Newpass' WHERE Email= '$email'";
                        if ($conn->query($up_sql) == TRUE)
                        {
                            header("location: login.php");
                        }
                        else
                        {
                            echo "Error: " . $sql_data . "<br>" . $conn->error;
                        }
                    }
                    else
                    {
                        $passErr="Password does not Match";
                    }
                }
            }
      }
    }
?>

<!-- Navbar  -->
<nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Lifestyle Store</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="index.php" class="btn"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                    <li><a href="product.php" class="btn"><span class="glyphicon glyphicon-search"></span> Product</a></li>
                    <li><a href="settings.php" class="btn active"><span class="glyphicon glyphicon-cog"></span> Settings</a></li>
                    <li><a href="cart.php" class="btn"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
                    <li><a href="index.php" class="btn"><span class="glyphicon glyphicon-log-out"></span> Log out</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Sign up form  -->
<div class="container" style="margin-top: 100px;">
  <div class="row">
    <div class="col-lg-5" style="margin:20px; padding:30px;">
    <img src="se1.png" alt="bg" style="left:0px;width: 400px;">
    </div>
    <div class="col-lg-6">
      <form class="form form-horizontal" style="margin-top: 20px; margin-bottom:50px;" method="post">
        <p><span class="error">*Don't forget to fill up required field</span></p>
          <!-- Old Password Field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">Password: </label>
            <div class="col-sm-5">
              <input class="form-control" type="password" name="oldpass" placeholder="Enter Old Password" id="oldpass" >
              <!-- checkbox to show and hide data  -->
              <input type="checkbox" onclick="myFunction('oldpass')">Show Password
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $passErr;?></span>
            </div>
          </div>
          <!-- New Password Field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">Enter New Password: </label>
            <div class="col-sm-5">
              <input class="form-control" type="password" name="New_pass"  placeholder="Please re-enter password" id="New_pass">
              <!-- checkbox to show and hide data  -->
              <input type="checkbox" onclick="myFunction('New_pass')">Show Password
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $New_passErr;?></span>
            </div>
          </div>
          <!-- Confirm New Password Field  -->
          <div class="form-group form-group-md">
            <label class="col-sm-3 control-label">Confirm New Password: </label>
            <div class="col-sm-5">
              <input class="form-control" type="password" name="reNew_pass"  placeholder="Please re-enter password" id="reNew_pass">
              <!-- checkbox to show and hide data  -->
              <input type="checkbox" onclick="myFunction('reNew_pass')">Show Password
            </div>
            <div class="col-sm-2">
              <span class="error">* <?php echo $reNew_passErr;?></span>
            </div>
          </div>
          <!-- Sign up button  -->
          <input class="btn btn-warning" id="update"type="submit" value="Update" name="update">
          <p>Alredy have an account  <a href="login.php"> Log in</a></p>
        </form>
      </div>
        <!-- Show and Hide script  -->
      <script>
      function myFunction(id) 
      {
        var x = document.getElementById(id);
        if (x.type === "password")
        {
          x.type = "text";
        }
        else
        {
          x.type = "password";
        }
      }
      </script>
  </div>
</div>
 <!-- footer  -->
 <?php 
      include('footer.php');
  ?>
</body>
</html>