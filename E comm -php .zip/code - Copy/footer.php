<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
    .footer {
        /* position: fixed; */
        left: 0;
        bottom: 0;
        width: 100%;
        background-color: black;
        color: white;
        text-align: center;
    }
    .footer h1{
        color:white;
    }
    ul{
        list-style-type: none;
    }
    ul a{
        text-align: center;
    }
    </style>
</head>
<body>
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-sm-4" >
                    <h1>Information</h1>
                    <ul class="list">
                        <li><a href="about.php">About us</a></li>
                        <li><a href="contact.php">Contact us</a></li>
                    </ul>
                </div>
                <div class="col-sm-4">
                <h1>My Account</h1>
                    <ul class="list">
                        <li><a href="">Sign up</a></li>
                        <li><a href="">Log in</a></li>
                    </ul>
                </div>
                <div class="col-sm-4">
                <h1>Contact us</h1>
                    <ul class="list">
                       <p> Contact:+91-123-000000</p>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>