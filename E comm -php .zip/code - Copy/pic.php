<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display picture</title>
</head>
<body>
<?php
$hostname="localhost"; 
$username="root";
$password="";
$database="user";
$conn=mysqli_connect($hostname,$username,$password,$database);
 
if(!$conn)
{
die("Connection cannot be establish: " . mysqli_connect_error());
}
$sql="SELECT image FROM table1 WHERE id=1 " ;
$result= mysqli_query($conn, $sql);
while ($row = mysqli_fetch_row($result)) 
{
    ?>
    <tr><td><img src="code/<?php echo $row['image']?>" width="450" height="200" /> </td>
    <?php 
}
?>
</body>
</html>